package cl.nisum.bffuser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BffUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(BffUserApplication.class, args);
	}

}
