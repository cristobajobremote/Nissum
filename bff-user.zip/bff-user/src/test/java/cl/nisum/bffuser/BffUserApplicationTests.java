package cl.nisum.bffuser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BffUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
